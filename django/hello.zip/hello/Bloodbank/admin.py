from django.contrib import admin
from Bloodbank.models import contact
# Register your models here.
admin.site.register(contact)